<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Pengguna</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root {
            --primary: #0077b6;
            --accent: #90e0ef;
            --danger: #ff6b6b;
            --bg: #f0f9ff;
            --text: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #f6fafe, #d6f3ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 40px 30px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 90%;
            text-align: center;
        }

        h2 {
            margin-bottom: 30px;
            color: var(--primary);
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .menu a {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 14px;
            background: var(--primary);
            color: white;
            text-decoration: none;
            font-weight: 500;
            border-radius: 10px;
            transition: 0.3s ease;
        }

        .menu a:hover {
            background: #005f88;
        }

        .menu a.logout {
            background: var(--danger);
        }

        .menu a.logout:hover {
            background: #e64949;
        }

        @media (max-width: 500px) {
            .container {
                padding: 25px 20px;
            }
            h2 {
                font-size: 20px;
            }
            .menu a {
                font-size: 14px;
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Selamat Datang, <?= htmlspecialchars($user['nama']) ?> 👋</h2>
        <div class="menu">
            <a href="booking.php">📅 Booking Lapangan</a>
            <a href="databooking.php">📋 Lihat Data Booking</a>
            <a class="logout" href="../logout.php">🚪 Logout</a>
        </div>
    </div>
</body>
</html>
