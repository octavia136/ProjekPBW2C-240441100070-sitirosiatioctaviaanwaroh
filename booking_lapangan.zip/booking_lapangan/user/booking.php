<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user']['id_user'];
$pesan = "";
$lapangan = mysqli_query($conn, "SELECT * FROM lapangan");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];

    date_default_timezone_set('Asia/Jakarta');
    $tanggal_hari_ini = date("Y-m-d");
    $jam_sekarang = date("H:i");

    if ($tanggal < $tanggal_hari_ini) {
        $pesan = "⛔ Tidak dapat booking tanggal yang sudah lewat.";
    } elseif ($tanggal == $tanggal_hari_ini && $jam_mulai <= $jam_sekarang) {
        $pesan = "⛔ Jam mulai tidak boleh di masa lalu.";
    } else {
        $cek = mysqli_query($conn, "SELECT * FROM booking 
            WHERE id_lapangan='$id_lapangan' AND tanggal='$tanggal' 
            AND (jam_mulai < '$jam_selesai' AND jam_selesai > '$jam_mulai')");

        if (mysqli_num_rows($cek) > 0) {
            $pesan = "⚠️ Jam tersebut sudah dibooking. Silakan pilih jam lain.";
        } else {
            mysqli_query($conn, "INSERT INTO booking 
                (id_user, id_lapangan, tanggal, jam_mulai, jam_selesai, status)
                VALUES ('$user_id', '$id_lapangan', '$tanggal', '$jam_mulai', '$jam_selesai', 'Menunggu Konfirmasi')");
            $pesan = "✅ Booking berhasil! Silakan tunggu konfirmasi admin.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Booking Lapangan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #e0f7fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1100px;
            margin: 30px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #0077b6;
            margin-bottom: 30px;
        }
        .alert {
            background: #fff3cd;
            color: #856404;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .lapangan-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
            gap: 20px;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            background: #f9fcff;
            transition: 0.3s;
        }
        .card:hover {
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        .card-body {
            padding: 15px;
        }
        .card-body h4 {
            margin: 0 0 10px;
            color: #0077b6;
        }
        .card-body p {
            margin: 5px 0;
            font-size: 14px;
        }
        .card-body label {
            font-size: 14px;
            display: block;
            margin-top: 8px;
        }
        .card-body input {
            width: 100%;
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }
        .card-body button {
            width: 100%;
            padding: 10px;
            background: #00b4d8;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .card-body button:hover {
            background: #0096c7;
        }
        .back-link {
            text-align: center;
            margin-top: 25px;
        }
        .back-link a {
            text-decoration: none;
            color: white;
            background: #0077b6;
            padding: 10px 20px;
            border-radius: 8px;
            display: inline-block;
        }
        @media (max-width: 768px) {
            .card-body p, label {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Form Booking Lapangan</h2>

    <?php if ($pesan): ?>
        <div class="alert"><?= $pesan ?></div>
    <?php endif; ?>

    <div class="lapangan-list">
        <?php
        $gambarList = ['b.jpeg', 'c.jpeg', 'a.jpeg', 'badminton.jpeg', 'futsal.jpeg', 'sepak takraw.jpeg', 'kolam berenang.jpeg', 'yoga.jpeg', 'tenis meja.jpeg'];
        $index = 0;
        while ($l = mysqli_fetch_assoc($lapangan)) {
            $gambar = $gambarList[$index % count($gambarList)];
        ?>
        <div class="card">
            <img src="<?= $gambar ?>" alt="<?= htmlspecialchars($l['nama_lapangan']) ?>">
            <div class="card-body">
                <h4><?= htmlspecialchars($l['nama_lapangan']) ?></h4>
                <p>📍 <?= htmlspecialchars($l['lokasi']) ?></p>
                <p>💰 Rp <?= number_format($l['harga_per_jam'], 0, ',', '.') ?>/jam</p>
                <form method="POST">
                    <input type="hidden" name="id_lapangan" value="<?= $l['id_lapangan'] ?>">
                    <label for="tanggal">Tanggal</label>
                    <input type="date" name="tanggal" required min="<?= date('Y-m-d') ?>">
                    <label for="jam_mulai">Jam Mulai</label>
                    <input type="time" name="jam_mulai" required>
                    <label for="jam_selesai">Jam Selesai</label>
                    <input type="time" name="jam_selesai" required>
                    <button type="submit">Booking Sekarang</button>
                </form>
            </div>
        </div>
        <?php $index++; } ?>
    </div>

    <div class="back-link">
        <a href="index.php">⬅ Kembali ke Dashboard</a>
    </div>
</div>
</body>
</html>
