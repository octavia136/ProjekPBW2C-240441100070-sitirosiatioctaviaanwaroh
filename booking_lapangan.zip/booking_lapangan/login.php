<?php
session_start();
include 'koneksi.php';

$pesan = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM user WHERE email='$email'");
    $user = mysqli_fetch_assoc($query);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;

        if ($user['role'] == 'admin') {
            header("Location: admin/index.php");
        } else {
            header("Location: user/index.php");
        }
        exit;
    } else {
        $pesan = "❌ Email atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            background: linear-gradient(135deg, #FFDEE9, #B5FFFC);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #444;
        }
        input[type=email], input[type=password] {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            background: #f9f9f9;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #4db8ff;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #3399ff;
        }
        .message {
            margin-top: 15px;
            background: #ffecec;
            color: #c00;
            padding: 10px;
            border-radius: 6px;
            text-align: center;
        }
        .register-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }
        .register-link a {
            color: #3399ff;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form class="login-box" method="POST">
        <h2>Login Pengguna</h2>

        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Kata Sandi" required>
        <button type="submit">Masuk</button>

        <?php if ($pesan): ?>
        <div class="message"><?= $pesan ?></div>
        <?php endif; ?>

        <div class="register-link">
            Belum punya akun? <a href="register.php">Daftar di sini</a>
        </div>
    </form>
</body>
</html>
