<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "ID booking tidak ditemukan.";
    exit;
}

$id = $_GET['id'];
$user_id = $_SESSION['user']['id_user'];

$query = mysqli_query($conn, "SELECT b.*, l.nama_lapangan, l.lokasi, u.nama
    FROM booking b
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    JOIN user u ON b.id_user = u.id_user
    WHERE b.id_booking = '$id' AND b.id_user = '$user_id'");

if (mysqli_num_rows($query) == 0) {
    echo "Data booking tidak ditemukan.";
    exit;
}

$data = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Bukti Booking Lapangan</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f9ff;
            padding: 40px;
        }

        .bukti {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 35px 40px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #0077b6;
            margin-bottom: 20px;
        }

        hr {
            border: none;
            border-top: 2px solid #eee;
            margin: 20px 0;
        }

        table {
            width: 100%;
            font-size: 16px;
        }

        td {
            padding: 10px 8px;
            vertical-align: top;
        }

        .label {
            font-weight: bold;
            width: 40%;
            color: #333;
        }

        .value {
            color: #555;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #555;
        }

        .actions {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 25px;
        }

        .actions button {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        .print-btn {
            background: #00b4d8;
            color: white;
        }

        .print-btn:hover {
            background: #0077b6;
        }

        .back-btn {
            background: #e0e0e0;
            color: #333;
        }

        .back-btn:hover {
            background: #d0d0d0;
        }

        @media print {
            .actions {
                display: none;
            }
            body {
                background: white;
                padding: 0;
            }
            .bukti {
                box-shadow: none;
                padding: 0;
            }
        }
    </style>
</head>
<body>
<div class="bukti">
    <h2>🧾 Bukti Booking Lapangan</h2>
    <hr>

    <table>
        <tr>
            <td class="label">📛 Nama Pemesan</td>
            <td class="value"><?= htmlspecialchars($data['nama']) ?></td>
        </tr>
        <tr>
            <td class="label">🏟️ Lapangan</td>
            <td class="value"><?= htmlspecialchars($data['nama_lapangan']) ?> - <?= htmlspecialchars($data['lokasi']) ?></td>
        </tr>
        <tr>
            <td class="label">📅 Tanggal Booking</td>
            <td class="value"><?= $data['tanggal'] ?></td>
        </tr>
        <tr>
            <td class="label">⏰ Waktu</td>
            <td class="value"><?= $data['jam_mulai'] ?> - <?= $data['jam_selesai'] ?></td>
        </tr>
        <tr>
            <td class="label">📌 Status</td>
            <td class="value"><?= $data['status'] ?></td>
        </tr>
    </table>

    <div class="actions">
        <button class="print-btn" onclick="window.print()">🖨 Cetak Bukti</button>
        <button class="back-btn" onclick="window.history.back()">⬅ Kembali</button>
    </div>

    <div class="footer">
        Terima kasih telah melakukan booking. Silakan tunjukkan bukti ini saat check-in di lapangan. <br>
        📍 Harap hadir 15 menit sebelum waktu yang telah ditentukan.
    </div>
</div>
</body>
</html>
