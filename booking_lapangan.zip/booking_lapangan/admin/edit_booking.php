<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "ID booking tidak ditemukan!";
    exit;
}

$id_booking = $_GET['id'];
$booking = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM booking WHERE id_booking='$id_booking'"));
$lapangan = mysqli_query($conn, "SELECT * FROM lapangan");
$pesan = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];

    // Validasi tabrakan jadwal (kecuali booking ini sendiri)
    $cek = mysqli_query($conn, "SELECT * FROM booking WHERE id_lapangan='$id_lapangan' AND tanggal='$tanggal' AND id_booking!='$id_booking' AND (
        (jam_mulai < '$jam_selesai' AND jam_selesai > '$jam_mulai')
    )");

    if (mysqli_num_rows($cek) > 0) {
        $pesan = "⚠️ Jadwal bentrok dengan booking lain.";
    } else {
        mysqli_query($conn, "UPDATE booking SET 
            id_lapangan='$id_lapangan',
            tanggal='$tanggal',
            jam_mulai='$jam_mulai',
            jam_selesai='$jam_selesai'
            WHERE id_booking='$id_booking'");

        header("Location: databooking.php?pesan=berhasil_edit");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Booking</title>
    <style>
        body { font-family: Arial; background: #f8f9fa; }
        .container {
            background: white;
            width: 500px;
            margin: 40px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #007bff; }
        form label { display: block; margin-top: 10px; }
        form input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        .btn {
            margin-top: 20px;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            width: 100%;
            border-radius: 6px;
            cursor: pointer;
        }
        .btn:hover { background: #0056b3; }
        .error {
            background: #fff3cd;
            padding: 10px;
            margin-top: 10px;
            border-radius: 6px;
            color: #856404;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit Booking</h2>

    <?php if ($pesan): ?>
        <div class="error"><?= $pesan ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Lapangan</label>
        <select name="id_lapangan" required>
            <?php while ($l = mysqli_fetch_assoc($lapangan)) { ?>
                <option value="<?= $l['id_lapangan'] ?>" <?= $l['id_lapangan'] == $booking['id_lapangan'] ? 'selected' : '' ?>>
                    <?= $l['nama_lapangan'] ?> - <?= $l['lokasi'] ?>
                </option>
            <?php } ?>
        </select>

        <label>Tanggal</label>
        <input type="date" name="tanggal" value="<?= $booking['tanggal'] ?>" required>

        <label>Jam Mulai</label>
        <input type="time" name="jam_mulai" value="<?= $booking['jam_mulai'] ?>" required>

        <label>Jam Selesai</label>
        <input type="time" name="jam_selesai" value="<?= $booking['jam_selesai'] ?>" required>

        <button class="btn" type="submit">Simpan Perubahan</button>
    </form>
</div>
</body>
</html>
