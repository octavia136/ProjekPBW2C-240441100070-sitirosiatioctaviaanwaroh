<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}
$admin = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #e3f2fd, #ffffff);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #1565c0;
            margin-bottom: 10px;
        }
        p.sub {
            color: #555;
            margin-bottom: 30px;
        }
        .menu {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .menu a {
            background: #e3f2fd;
            border: 2px solid #90caf9;
            padding: 15px;
            border-radius: 10px;
            font-size: 17px;
            color: #0d47a1;
            font-weight: 600;
            text-decoration: none;
            transition: 0.3s ease;
        }
        .menu a:hover {
            background: #bbdefb;
            transform: scale(1.03);
        }

        footer {
            margin-top: 40px;
            font-size: 14px;
            color: #999;
        }

        @media (max-width: 600px) {
            .container {
                margin: 20px;
                padding: 25px;
            }
            .menu a {
                font-size: 16px;
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Selamat Datang, <?= htmlspecialchars($admin['nama']) ?>! 👋</h1>
        <p class="sub">Silakan pilih menu untuk mengelola sistem booking lapangan.</p>

        <div class="menu">
            <a href="lapangan.php">⚽ Kelola Data Lapangan</a>
            <a href="booking.php">🕒 Lihat Data Booking</a>
            <a href="laporan.php">📊 Laporan & Grafik</a>
            <a href="../logout.php">🚪 Logout</a>
        </div>

        <footer>&copy; <?= date('Y') ?> Sistem Booking Lapangan - Admin Panel</footer>
    </div>
</body>
</html>
