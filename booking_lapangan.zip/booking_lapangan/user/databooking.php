<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user']['id_user'];
$booking = mysqli_query($conn, "SELECT b.*, l.nama_lapangan, l.lokasi FROM booking b
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    WHERE b.id_user = '$user_id' ORDER BY b.tanggal DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Booking Saya</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root {
            --primary: #0077b6;
            --accent: #caf0f8;
            --text: #333;
            --bg: #f0fbff;
            --hover: #90e0ef;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: var(--bg);
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: var(--primary);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 14px 12px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 15px;
        }

        th {
            background: var(--accent);
            color: var(--text);
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        .button {
            background: var(--primary);
            color: white;
            padding: 8px 14px;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: background 0.3s ease;
        }

        .button:hover {
            background: #0096c7;
        }

        .back-link {
            display: inline-block;
            margin-top: 18px;
            padding: 10px 16px;
            text-decoration: none;
            color: white;
            background: #6c757d;
            border-radius: 8px;
        }

        .back-link:hover {
            background: #5a6268;
        }

        @media (max-width: 600px) {
            th, td {
                font-size: 13px;
                padding: 10px 8px;
            }
            .button, .back-link {
                font-size: 13px;
                padding: 8px 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>📋 Riwayat Booking Anda</h2>

        <?php if (mysqli_num_rows($booking) > 0) { ?>
        <table>
            <thead>
                <tr>
                    <th>Lapangan</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Status</th>
                    <th>Bukti</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($b = mysqli_fetch_assoc($booking)) { ?>
                <tr>
                    <td><?= htmlspecialchars($b['nama_lapangan']) ?><br><small>📍 <?= htmlspecialchars($b['lokasi']) ?></small></td>
                    <td><?= $b['tanggal'] ?></td>
                    <td><?= $b['jam_mulai'] ?> - <?= $b['jam_selesai'] ?></td>
                    <td>
                        <?php
                        $status = $b['status'];
                        if ($status == 'Menunggu Konfirmasi') echo '⏳ ' . $status;
                        elseif ($status == 'Dikonfirmasi') echo '✅ ' . $status;
                        elseif ($status == 'Ditolak') echo '❌ ' . $status;
                        else echo $status;
                        ?>
                    </td>
                    <td><a class="button" href="cetak_bukti.php?id=<?= $b['id_booking'] ?>">🖨 Cetak</a></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php } else { ?>
            <p style="text-align:center; color:gray;">Belum ada booking yang tercatat.</p>
        <?php } ?>

        <a class="back-link" href="index.php">⬅ Kembali ke Dashboard</a>
    </div>
</body>
</html>
