<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";
$edit = false;
$edit_data = [
    'id_lapangan' => '',
    'nama_lapangan' => '',
    'lokasi' => '',
    'harga_per_jam' => ''
];

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_lapangan'];
    $lokasi = $_POST['lokasi'];
    $harga = $_POST['harga_per_jam'];
    mysqli_query($conn, "INSERT INTO lapangan (nama_lapangan, lokasi, harga_per_jam) VALUES ('$nama', '$lokasi', '$harga')");
    $pesan = "✅ Lapangan berhasil ditambahkan.";
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM lapangan WHERE id_lapangan = '$id'");
    $pesan = "❌ Lapangan berhasil dihapus.";
}

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM lapangan WHERE id_lapangan = '$id'");
    $edit_data = mysqli_fetch_assoc($result);
    $edit = true;
}

if (isset($_POST['update'])) {
    $id = $_POST['id_lapangan'];
    $nama = $_POST['nama_lapangan'];
    $lokasi = $_POST['lokasi'];
    $harga = $_POST['harga_per_jam'];

    mysqli_query($conn, "UPDATE lapangan SET 
        nama_lapangan = '$nama',
        lokasi = '$lokasi',
        harga_per_jam = '$harga'
        WHERE id_lapangan = '$id'");

    $pesan = "✅ Lapangan berhasil diupdate.";
    $edit = false;
}

$lapangan = mysqli_query($conn, "SELECT * FROM lapangan ORDER BY id_lapangan DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Lapangan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f2f9ff;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2, h3 {
            text-align: center;
            color: #0077b6;
        }
        form {
            margin-bottom: 30px;
        }
        label {
            display: block;
            margin-top: 12px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #0077b6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #023e8a;
        }
        .error {
            color: green;
            margin-top: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #cce5ff;
            text-align: center;
        }
        th {
            background-color: #caf0f8;
            color: #023e8a;
        }
        tr:nth-child(even) {
            background-color: #f1faff;
        }
        a.hapus, a.edit {
            text-decoration: none;
            font-weight: bold;
            margin: 0 5px;
        }
        a.hapus { color: red; }
        a.edit { color: orange; }

        a.dashboard {
            display: inline-block;
            margin-top: 20px;
            background-color: #0096c7;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
        }

        /* Galeri */
        #cari {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        .card .info {
            padding: 15px;
        }
        .card h4 {
            margin: 0 0 10px;
            color: #0077b6;
        }
        .card p {
            font-size: 14px;
            color: #555;
        }

        @media (max-width: 768px) {
            table, th, td {
                font-size: 13px;
            }
            .container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2><?= $edit ? 'Edit Lapangan' : 'Kelola Lapangan' ?></h2>

    <form method="POST">
        <?php if ($edit): ?>
            <input type="hidden" name="id_lapangan" value="<?= $edit_data['id_lapangan'] ?>">
        <?php endif; ?>

        <label>Nama Lapangan</label>
        <input type="text" name="nama_lapangan" value="<?= htmlspecialchars($edit_data['nama_lapangan']) ?>" required>

        <label>Lokasi</label>
        <input type="text" name="lokasi" value="<?= htmlspecialchars($edit_data['lokasi']) ?>" required>

        <label>Harga per Jam</label>
        <input type="number" name="harga_per_jam" value="<?= htmlspecialchars($edit_data['harga_per_jam']) ?>" required>

        <?php if ($edit): ?>
            <button type="submit" name="update">💾 Simpan Perubahan</button>
            <a href="lapangan.php" style="margin-left: 10px;">❌ Batal</a>
        <?php else: ?>
            <button type="submit" name="tambah">+ Tambah Lapangan</button>
        <?php endif; ?>
    </form>

    <?php if ($pesan): ?>
        <p class="error"><?= $pesan ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>Nama</th>
            <th>Lokasi</th>
            <th>Harga/Jam</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($lapangan)) { ?>
        <tr>
            <td><?= htmlspecialchars($row['nama_lapangan']) ?></td>
            <td><?= htmlspecialchars($row['lokasi']) ?></td>
            <td>Rp<?= number_format($row['harga_per_jam']) ?></td>
            <td>
                <a href="?edit=<?= $row['id_lapangan'] ?>" class="edit">✏ Edit</a>
                <a href="?hapus=<?= $row['id_lapangan'] ?>" class="hapus" onclick="return confirm('Hapus lapangan ini?')">🗑 Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <a href="index.php" class="dashboard">⬅ Kembali ke Dashboard</a>
    <a href="cetak_lapangan.php" target="_blank" class="dashboard" style="background-color: #4caf50;">📄 Cetak / Simpan PDF</a>

    <h3>Galeri Lapangan</h3>
    <input type="text" id="cari" placeholder="🔍 Cari lapangan..." onkeyup="filterLapangan()">

    <div class="grid" id="galeri">
        <div class="card">
            <img src="a.jpeg" alt="Lapangan Basket">
            <div class="info">
                <h4>Lapangan Basket</h4>
                <p>Lapangan futsal indoor berstandar nasional, cocok untuk pertandingan resmi atau latihan tim.</p>
            </div>
        </div>
        <div class="card">
            <img src="c.jpeg" alt="Lapangan Olahraga">
            <div class="info">
                <h4>Lapangan Sepak Bola</h4>
                <p>Lapangan outdoor rumput sintetis, nyaman dan luas untuk berbagai jenis olahraga tim.</p>
            </div>
        </div>
        <div class="card">
            <img src="b.jpeg" alt="Lapangan">
            <div class="info">
                <h4>Lapangan Atletis</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
             </div>
        <div class="card">
            <img src="badminton.jpeg" alt="Lapangan badminton">
            <div class="info">
                <h4>Lapangan Badminton</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
        </div>
        <div class="card">
            <img src="futsal.jpeg" alt="Lapangan">
            <div class="info">
                <h4>Lapangan Futsal</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
        </div>
        <div class="card">
            <img src="sepak takraw.jpeg" alt="Lapangan">
            <div class="info">
                <h4>Lapangan Sepak Takraw</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
        </div>
        <div class="card">
            <img src="kolam berenang.jpeg" alt="Lapangan">
            <div class="info">
                <h4>Lapangan Kolam Berenang</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
        </div>
        <div class="card">
            <img src="yoga.jpeg" alt="Lapangan">
            <div class="info">
                <h4>Lapangan Yoga</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
        </div>
        <div class="card">
            <img src="tenis meja.jpeg" alt="Lapangan">
            <div class="info">
                <h4>Lapangan Tenis Meja</h4>
                <p>Lapangan serbaguna dengan fasilitas pencahayaan malam hari dan tribun kecil penonton.</p>
            </div>
        </div>
    </div>
</div>

<script>
function filterLapangan() {
    const input = document.getElementById("cari").value.toLowerCase();
    const cards = document.querySelectorAll(".card");

    cards.forEach(card => {
        const title = card.querySelector("h4").textContent.toLowerCase();
        card.style.display = title.includes(input) ? "block" : "none";
    });
}
</script>
</body>
</html>
